#include <Arduino.h>
#include "qrencode.h"
#include "qrcode_espi.h"


QRcode_eSPI::QRcode_eSPI(TFT_eSPI *display) {
    this->display = display;
}


void QRcode_eSPI::init() {
    this->screenwidth = display->width();
    this->screenheight = display->height();
    display->fillScreen(TFT_WHITE);
    // Set the size of the QR code to 80x80 pixels
    int qrCodeSize = 180; // Desired QR code size in pixels
    multiply = qrCodeSize / WD; // Calculate the size of each module

    // Calculate offsets to center the QR code (optional)
    offsetsX = (screenwidth - qrCodeSize) / 2;
    //offsetsY = (screenheight - qrCodeSize) / 2;
    //offsetsX = 74;
    offsetsY = 105;
    // Clear space for QR code with a small margin around it
    // Assuming you want a margin of 10 pixels around the QR code
    int margin = 10;
//    display->fillRect(offsetsX - margin, offsetsY - margin, qrCodeSize + (2 * margin), qrCodeSize + (2 * margin),
//                      TFT_YELLOW);
}

void QRcode_eSPI::create(String message) {
    display->startWrite();
    QRcodeDisplay::create(message);
    display->endWrite();
}

void QRcode_eSPI::screenwhite() {
    display->fillScreen(TFT_WHITE);
}

void QRcode_eSPI::screenupdate() {
    // No hay que hacer nada
}

void QRcode_eSPI::drawPixel(int x, int y, int color) {
    if (color == 1) {
        color = TFT_BLACK;
    } else {
        color = TFT_WHITE;
    }
    display->drawPixel(x, y, color);
    if (this->multiply > 1) {
        display->fillRect(x, y, multiply, multiply, color);
    }
}